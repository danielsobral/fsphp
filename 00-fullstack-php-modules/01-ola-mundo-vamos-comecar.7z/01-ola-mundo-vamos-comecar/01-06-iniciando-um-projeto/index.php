<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Começando um projeto</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<?php
$start = "Vamos começar pessoal!";
echo "<h1>Olá mundo! {$start}</h1>";
echo "<div id='js'>Loading</div>";
?>
<script src="assets/script.js"></script>
</body>
</html>