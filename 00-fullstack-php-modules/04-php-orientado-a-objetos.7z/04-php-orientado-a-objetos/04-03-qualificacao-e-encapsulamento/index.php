<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("04.03 - Qualificação e encapsulamento");

/*
 * [ namespaces ] http://php.net/manual/pt_BR/language.namespaces.basics.php
 */
fullStackPHPClassSession("namespaces", __LINE__);

require __DIR__."/classes/App/Template.php";
require __DIR__."/classes/Web/Template.php";

$appTemplate = new App\Template();
$webTemplate = new Web\Template();

var_dump(
    $appTemplate,
    $webTemplate
);

use App\Template;
use Source\Qualifield\User;
use Web\Template AS webTemplate;

$appUsetemplate = new Template();
$webUseTemplate = new webTemplate();

var_dump(
    $appUsetemplate,
    $webUseTemplate
);

/*
 * [ visibilidade ] http://php.net/manual/pt_BR/language.oop5.visibility.php
 */
fullStackPHPClassSession("visibilidade", __LINE__);

require __DIR__."/source/Qualifield/User.php";

$user = new User();

// $user->firstName = "Daniel";
// $user->lastName = "Nascimento";

// $user->setFirstName("Daniel");
// $user->setLastName("Nascimento");



var_dump(
    $user,
    get_class_methods($user)
);

echo "<p>O e-mail do usuário {$user->getFirstName()} é {$user->getEmail()}</p>";

/*
 * [ manipulação ] Classes com estruturas que abstraem a rotina de manipulação de objetos
 */
fullStackPHPClassSession("manipulação", __LINE__);

$daniel = $user->setUser("Daniel", "Nascimento", "daniel@mosyle.com");

if (!$daniel) {
    echo "<p class='trigger error'>{$user->getError()}</p>";
}

var_dump($user);
