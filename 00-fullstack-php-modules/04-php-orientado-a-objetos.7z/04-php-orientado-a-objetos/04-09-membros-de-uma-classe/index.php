<?php

use Source\Members\Config;
use Source\Members\Trigger;

require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("04.09 - Membros de uma classe");

require __DIR__ . "/source/autoload.php";

/*
 * [ constantes ] http://php.net/manual/pt_BR/language.oop5.constants.php
 */
fullStackPHPClassSession("constantes", __LINE__);

$config = new Config();
echo "<p>".$config::COMPANY."</p>";

var_dump(
    $config::COMPANY,
    // $config::DOMAIN,
    // $config::SECTOR
);

$reflection = new ReflectionClass($config);

var_dump($reflection, get_class_methods($reflection));

var_dump($config, $reflection->getConstants());

/*
 * [ propriedades ] http://php.net/manual/pt_BR/language.oop5.static.php
 */
fullStackPHPClassSession("propriedades", __LINE__);

Config::$company = "Mosyle";
$config::$domain = "mosyle.com";
$config::$sector = "MDM";

var_dump(
    $config, 
    $reflection->getProperties(), 
    $reflection->getDefaultProperties()
);


/*
 * [ métodos ] http://php.net/manual/pt_BR/language.oop5.static.php
 */
fullStackPHPClassSession("métodos", __LINE__);

$config::setConfig("Mosyle", "mosyle.com", "MDM");
Config::setConfig("Mosyle", "mosyle.com", "MDM");

var_dump($config, $reflection->getMethods(), $reflection->getDefaultProperties());

/*
 * [ exemplo ] Uma classe trigger
 */
fullStackPHPClassSession("exemplo", __LINE__);

$trigger = new Trigger();

$trigger::show("Um objeto trigger");

var_dump($trigger);

Trigger::show("Essa é uma mensagem para o usuário", Trigger::ACCEPT);
Trigger::show("Essa é uma mensagem para o usuário", Trigger::WARNING);
Trigger::show("Essa é uma mensagem para o usuário", Trigger::ERROR);

echo Trigger::push("Essa é uma mensagem para o usuário");