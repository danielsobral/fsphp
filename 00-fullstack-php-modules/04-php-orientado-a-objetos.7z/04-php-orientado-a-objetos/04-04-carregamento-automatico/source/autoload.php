<?php
spl_autoload_register(function($class){
    $prefix = "Source\\";
    $baseDir = __DIR__."/";
    $len = strlen($prefix);

    if (strncmp($class, $prefix, $len) !== 0)
        return;

    $relativeClass = substr($class, $len);

    $file = $baseDir.str_replace("\\", "/", $relativeClass).".php";

    if (file_exists($file))
        require $file;
});




// spl_autoload_register(function($class){
//     $prefix = "Source\\";
//     $baseDir = __DIR__."/";

//     $len = strlen($prefix);

//     var_dump([
//         "strncmp" => strncmp($prefix, $class, $len)
//     ]);

//     if (strncmp($prefix, $class, $len) !== 0 ) {
//         return;
//     }

//     $relativeClass = substr($class, $len);
//     var_dump([
//         "relativeClass" => $relativeClass
//     ]);

//     $file = $baseDir.str_replace("\\", "/", $relativeClass).".php";
//     var_dump([
//         "File" => $file
//     ]);

//     if (file_exists($file)) {
//         require $file;
//     }

//     var_dump([
//         "class" => $class,
//         "prefix" => $prefix,
//         "baseDir" => $baseDir,
//         "len" => $len,
//     ]);
// });