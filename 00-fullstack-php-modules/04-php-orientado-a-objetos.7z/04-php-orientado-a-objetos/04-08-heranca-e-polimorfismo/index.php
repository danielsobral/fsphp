<?php

use Source\Inheritance\Address;
use Source\Inheritance\Event\Event;
use Source\Inheritance\Event\EventLive;
use Source\Inheritance\Event\EventOnline;

require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("04.08 - Herança e polimorfismo");

require __DIR__ . "/source/autoload.php";

/*
 * [ classe pai ] Uma classe que define o modelo base da estrutura da herança
 * http://php.net/manual/pt_BR/language.oop5.inheritance.php
 */
fullStackPHPClassSession("classe pai", __LINE__);

$event = new Event(
    "Workshop FSPHP",
    new DateTime("2022-11-25 16:00"),
    2500,
    4
);

var_dump($event);

$event->register("Danielly Sobral do Nascimento", "daniellysn@outlook.com");
$event->register("Daniel Sobral do Nascimento", "danielsobralnascimento@hotmail.com");
$event->register("Bruna Larissa Monteiro do Nascimento", "brunalarissamonteiro@gmail.com");
$event->register("Mariana Monteiro", "mariana@gmail.com");
$event->register("Lenhare", "lenhare@gmail.com");



/*
 * [ classe filha ] Uma classe que herda a classe pai e especializa seuas rotinas
 */
fullStackPHPClassSession("classe filha", __LINE__);

$address = new Address("Av Brasil", "1680", "112 Bloco B");
$eventLive = new EventLive(
    "Workshop FSPHP",
    new DateTime("2022-11-25 16:00"),
    2500,
    4,
    $address
);

$eventLive->register("Daniel Sobral do Nascimento", "danielsobralnascimento@hotmail.com");
$eventLive->register("Danielly Sobral do Nascimento", "daniellysn@outlook.com");
$eventLive->register("Bruna Larissa Monteiro do Nascimento", "brunalarissamonteiro@gmail.com");
$eventLive->register("Mariana Monteiro", "mariana@gmail.com");
$eventLive->register("Lenhare", "lenhare@gmail.com");

var_dump($eventLive);

/*
 * [ polimorfismo ] Uma classe filha que tem métodos iguais (mesmo nome e argumentos) a class
 * pai, mas altera o comportamento desses métodos para se especializar
 */
fullStackPHPClassSession("polimorfismo", __LINE__);

$eventOnline = new EventOnline(
    "Workshop FSPHP",
    new DateTime("2022-11-25 16:00"),
    197,
    "https://upinside.com.br/aovivo",
);

$eventOnline->register("Daniel Sobral do Nascimento", "danielsobralnascimento@hotmail.com");
$eventOnline->register("Danielly Sobral do Nascimento", "daniellysn@outlook.com");
$eventOnline->register("Bruna Larissa Monteiro do Nascimento", "brunalarissamonteiro@gmail.com");
$eventOnline->register("Mariana Monteiro", "mariana@gmail.com");
$eventOnline->register("Lenhare", "lenhare@gmail.com");

var_dump($eventOnline);
