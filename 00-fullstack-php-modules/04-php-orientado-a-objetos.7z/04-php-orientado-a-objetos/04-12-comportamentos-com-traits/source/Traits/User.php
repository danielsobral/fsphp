<?php

namespace Source\Traits;

class User
{
    private $firstName;
    private $lasttName;
    private $email;

    public function __construct($firstName, $lastName, $email)
    {
        $this->firstName = $firstName;
        $this->lasttName = $lastName;
        $this->email = $email;
    }

    /**
     * Get the value of firstName
     */ 
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * Get the value of lasttName
     */ 
    public function getLasttName()
    {
        return $this->lasttName;
    }

    /**
     * Get the value of email
     */ 
    public function getEmail()
    {
        return $this->email;
    }
}