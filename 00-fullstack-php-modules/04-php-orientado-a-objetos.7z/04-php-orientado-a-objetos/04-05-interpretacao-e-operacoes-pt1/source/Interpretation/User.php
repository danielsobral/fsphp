<?php
namespace Source\Interpretation;

class User
{
    private $firstName;
    private $lastName;
    private $email;

    public function __construct($firstName, $lastName = true, $email = null)
    {
        $this->$firstName = $firstName;
        $this->$lastName = $lastName;
        $this->$email = $email;
    }

    public function __clone()
    {
        $this->setFirstName(null);
        $this->setLastName(null);
        echo "<p class='trigger'>Clonou Miséra</p>";
    }

    public function __destruct()
    {
        var_dump($this);
        echo "<p class='trigger accept'>O objeto {$this->getFirstName()} foi destruido!</p>";
    }

    /**
     * Get the value of firstName
     */ 
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * Get the value of lastName
     */ 
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Get the value of email
     */ 
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of firstName
     *
     * @return  self
     */ 
    public function setFirstName($firstName): self
    {
        $this->firstName = $firstName;

        return $this;
    }

    /**
     * Set the value of lastName
     *
     * @return  self
     */ 
    public function setLastName($lastName): self
    {
        $this->lastName = $lastName;

        return $this;
    }

    /**
     * Set the value of email
     *
     * @return  self
     */ 
    public function setEmail($email): self
    {
        $this->email = $email;

        return $this;
    }
}