<?php

class User
{
    public $firstName;
    public $lastName;
    public $email;

    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * Get the value of first name
     * @return self
     */

    public function setFirstName(string $firstName): void
    {
        $this->firstName = filter_var($firstName, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    }

    /**
     * Get the value of lastName
     */ 
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Set the value of lastName
     *
     * @return  self
     */ 
    public function setLastName($lastName): void
    {
        $this->lastName = filter_var($lastName, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    }

    /**
     * Get the value of email
     */ 
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     *
     * @return  boll
     */ 
    public function setEmail($email): bool
    {
        $this->email = $email;

        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return true;
        } else {
            return false;
        }
    }
}
