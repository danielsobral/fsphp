<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("04.02 - Classes, propriedades e objetos");

/*
 * [ classe e objeto ] http://php.net/manual/pt_BR/language.oop5.basic.php
 */
fullStackPHPClassSession("classe e objeto", __LINE__);

require __DIR__."/classes/User.php";

$user = new User();
var_dump($user);

echo "O e-mail do {$user->firstName} é o {$user->email}";
/*
 * [ propriedades ] http://php.net/manual/pt_BR/language.oop5.properties.php
 */
fullStackPHPClassSession("propriedades", __LINE__);

$user->firstName = "Daniel";
$user->lastName = "Nascimento";
$user->email = "daniel.nascimento@mosyle.com";

var_dump($user);
/*
 * [ métodos ] São as funções que definem o comportamento e a regra de negócios de uma classe
 */
fullStackPHPClassSession("métodos", __LINE__);

$user->setFirstName("Daniel");
$user->setLastName("Nascimento");

if (!$user->setEmail("daniel@gmail.com")) {
    echo "<p>O e-mail informado não é valido</p>";
} else {
    echo "<p>O e-mail informado {$user->getEmail()} é valido</p>";
}

var_dump($user);