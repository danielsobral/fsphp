<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.02 - Definindo ambiente");

/*
 * Documentando o exemplo do código
 */
fullStackPHPClassSession("Debug Section", __LINE__);

var_dump($_SERVER);