<?php
define("COURSE", "FSPHP");